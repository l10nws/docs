--
-- L10n database
--

CREATE DATABASE "l10n-portal"
  WITH OWNER = "postgres"
       ENCODING = 'UTF8'
       TABLESPACE = pg_default;
