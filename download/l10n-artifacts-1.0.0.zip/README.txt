L10n Setup

Artifacts:
 - l10n_schema_db.sql, sql schema
 - l10n-config.xml, configuration for l10n api and portal
 - l10n-api.war, web archive ready to deploy, need access to database from l10n-config.xml
 - l10n-portal.war, web archive ready to deploy, need to configure with l10n-config.xml

SQL Schema
 SQL script ready to run in your database. If you already created database delete in script database creation.
 If you want to use another db user check username in creation database command and in <datasource> l10n-config.xml.

L10n API & Portal
 Before deploy artifacts you need to set 'L10N_CONFIG_DIR' system environment var.
 'L10N_CONFIG_DIR' is full path to directory with 'l10n-config.xml'.
 After you can deploy api and portal as web application in servlet container. We recommend Apache Tomcat,
 see https://tomcat.apache.org/tomcat-7.0-doc/deployer-howto.html


