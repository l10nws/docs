CREATE TABLE portal_user (
  id           SERIAL       PRIMARY KEY,
  email        VARCHAR(64)  NOT NULL,
  first_name   VARCHAR(64),
  last_name    VARCHAR(64),
  role         VARCHAR(100) NOT NULL DEFAULT 'ROLE_USER',
  password     VARCHAR(200) NOT NULL,
  access_token VARCHAR(64)  NOT NULL,
  UNIQUE (email),
  UNIQUE (access_token)
);

CREATE TABLE persistent_logins (
  username  VARCHAR(64) NOT NULL,
  series    VARCHAR(64) PRIMARY KEY,
  token     VARCHAR(64) NOT NULL,
  last_used TIMESTAMP   NOT NULL
);

CREATE TABLE auth_token (
  user_id      INTEGER      NOT NULL REFERENCES portal_user (id),
  auth_token   VARCHAR(64)  NOT NULL,
  update_date  TIMESTAMP    NOT NULL,
  UNIQUE (auth_token)
);

CREATE TABLE project (
  id            SERIAL PRIMARY KEY,
  name          VARCHAR(64) NOT NULL,
  owner_id      INTEGER     NOT NULL REFERENCES portal_user (id),
  description   TEXT,
  creation_date TIMESTAMP   NOT NULL
);

CREATE TABLE user_permission (
  user_id    INTEGER     NOT NULL REFERENCES portal_user (id),
  project_id INTEGER     NOT NULL REFERENCES project (id),
  permission VARCHAR(64) NOT NULL,
  UNIQUE (user_id, project_id)
);

CREATE TABLE locales (
  id       VARCHAR NOT NULL PRIMARY KEY,
  language VARCHAR NOT NULL,
  country  VARCHAR NOT NULL
);

CREATE TABLE message_bundle (
  id            SERIAL PRIMARY KEY,
  label         VARCHAR(64) NULL,
  uid           VARCHAR(64) NOT NULL,
  owner_id      INTEGER     NOT NULL REFERENCES portal_user (id),
  creation_date TIMESTAMP   NOT NULL,
  project_id    INTEGER     NOT NULL REFERENCES project (id)
);

CREATE TABLE bundle_version (
  id                SERIAL PRIMARY KEY,
  version           VARCHAR   NOT NULL,
  creation_date     TIMESTAMP NOT NULL,
  modification_date TIMESTAMP,
  view_date TIMESTAMP,
  default_locale_id VARCHAR   NOT NULL REFERENCES locales (id),
  message_bundle_id INTEGER   NOT NULL REFERENCES message_bundle (id) ON DELETE CASCADE
);

CREATE TABLE locale_version (
  id         SERIAL PRIMARY KEY,
  locale_id  VARCHAR NOT NULL REFERENCES locales (id),
  version_id INTEGER NOT NULL REFERENCES bundle_version (id) ON DELETE CASCADE
);

CREATE SEQUENCE message_id_seq;

CREATE TABLE message (
  id BIGINT DEFAULT nextval('message_id_seq') PRIMARY KEY,
  version_id      INTEGER     NOT NULL,
  locale_id       VARCHAR     NOT NULL REFERENCES locales (id),
  key             TEXT        NOT NULL,
  value           TEXT
);

CREATE OR REPLACE FUNCTION bundle_version_insert_trigger_function() RETURNS TRIGGER AS
$$
  BEGIN
    EXECUTE 'CREATE TABLE message_' || NEW.id || ' (id BIGINT DEFAULT nextval(''message_id_seq'') PRIMARY KEY, CHECK (version_id = ' || NEW.id || '), UNIQUE (locale_id, key)) INHERITS (message)';
    RETURN NEW;
  END;
$$

LANGUAGE plpgsql;

CREATE TRIGGER bundle_version_insert_trigger AFTER INSERT ON bundle_version FOR EACH ROW EXECUTE PROCEDURE bundle_version_insert_trigger_function();

CREATE OR REPLACE FUNCTION bundle_version_delete_trigger_function() RETURNS TRIGGER AS
  $$
  BEGIN
    EXECUTE 'DROP TABLE message_' || OLD.id;
    RETURN OLD;
  END;
$$

LANGUAGE plpgsql;

CREATE TRIGGER bundle_version_delete_trigger AFTER DELETE ON bundle_version FOR EACH ROW EXECUTE PROCEDURE bundle_version_delete_trigger_function();

CREATE OR REPLACE FUNCTION message_insert_trigger_function() RETURNS TRIGGER AS
$$
  BEGIN
    EXECUTE 'insert into message_' || NEW.version_id || '(version_id, locale_id, key, value) values($1, $2, $3, $4)'
      USING NEW.version_id, NEW.locale_id, NEW.key, NEW.value;
    RETURN NULL;
  END;
$$

LANGUAGE plpgsql;

CREATE TRIGGER message_insert_trigger BEFORE INSERT ON message FOR EACH ROW EXECUTE PROCEDURE message_insert_trigger_function();

INSERT INTO locales (id, language, country) VALUES ('sq_AL', 'Albanian', 'Albania');
INSERT INTO locales (id, language, country) VALUES ('ar_DZ', 'Arabic', 'Algeria');
INSERT INTO locales (id, language, country) VALUES ('ar_BH', 'Arabic', 'Bahrain');
INSERT INTO locales (id, language, country) VALUES ('ar_EG', 'Arabic', 'Egypt');
INSERT INTO locales (id, language, country) VALUES ('ar_IQ', 'Arabic', 'Iraq');
INSERT INTO locales (id, language, country) VALUES ('ar_JO', 'Arabic', 'Jordan');
INSERT INTO locales (id, language, country) VALUES ('ar_KW', 'Arabic', 'Kuwait');
INSERT INTO locales (id, language, country) VALUES ('ar_LB', 'Arabic', 'Lebanon');
INSERT INTO locales (id, language, country) VALUES ('ar_LY', 'Arabic', 'Libya');
INSERT INTO locales (id, language, country) VALUES ('ar_MA', 'Arabic', 'Morocco');
INSERT INTO locales (id, language, country) VALUES ('ar_OM', 'Arabic', 'Oman');
INSERT INTO locales (id, language, country) VALUES ('ar_QA', 'Arabic', 'Qatar');
INSERT INTO locales (id, language, country) VALUES ('ar_SA', 'Arabic', 'Saudi Arabia');
INSERT INTO locales (id, language, country) VALUES ('ar_SD', 'Arabic', 'Sudan');
INSERT INTO locales (id, language, country) VALUES ('ar_SY', 'Arabic', 'Syria');
INSERT INTO locales (id, language, country) VALUES ('ar_TN', 'Arabic', 'Tunisia');
INSERT INTO locales (id, language, country) VALUES ('ar_AE', 'Arabic', 'United Arab Emirates');
INSERT INTO locales (id, language, country) VALUES ('ar_YE', 'Arabic', 'Yemen');
INSERT INTO locales (id, language, country) VALUES ('be_BY', 'Belarusian', 'Belarus');
INSERT INTO locales (id, language, country) VALUES ('bg_BG', 'Bulgarian', 'Bulgaria');
INSERT INTO locales (id, language, country) VALUES ('ca_ES', 'Catalan', 'Spain');
INSERT INTO locales (id, language, country) VALUES ('zh_CN', 'Chinese (Simplified)', 'China');
INSERT INTO locales (id, language, country) VALUES ('zh_SG', 'Chinese (Simplified)', 'Singapore');
INSERT INTO locales (id, language, country) VALUES ('zh_HK', 'Chinese (Traditional)', 'Hong Kong');
INSERT INTO locales (id, language, country) VALUES ('zh_TW', 'Chinese (Traditional)', 'Taiwan');
INSERT INTO locales (id, language, country) VALUES ('hr_HR', 'Croatian', 'Croatia');
INSERT INTO locales (id, language, country) VALUES ('cs_CZ', 'Czech', 'Czech Republic');
INSERT INTO locales (id, language, country) VALUES ('da_DK', 'Danish', 'Denmark');
INSERT INTO locales (id, language, country) VALUES ('nl_BE', 'Dutch', 'Belgium');
INSERT INTO locales (id, language, country) VALUES ('nl_NL', 'Dutch', 'Netherlands');
INSERT INTO locales (id, language, country) VALUES ('en_AU', 'English', 'Australia');
INSERT INTO locales (id, language, country) VALUES ('en_CA', 'English', 'Canada');
INSERT INTO locales (id, language, country) VALUES ('en_IN', 'English', 'India');
INSERT INTO locales (id, language, country) VALUES ('en_IE', 'English', 'Ireland');
INSERT INTO locales (id, language, country) VALUES ('en_MT', 'English', 'Malta');
INSERT INTO locales (id, language, country) VALUES ('en_NZ', 'English', 'New Zealand');
INSERT INTO locales (id, language, country) VALUES ('en_PH', 'English', 'Philippines');
INSERT INTO locales (id, language, country) VALUES ('en_SG', 'English', 'Singapore');
INSERT INTO locales (id, language, country) VALUES ('en_ZA', 'English', 'South Africa');
INSERT INTO locales (id, language, country) VALUES ('en_GB', 'English', 'United Kingdom');
INSERT INTO locales (id, language, country) VALUES ('en_US', 'English', 'United States');
INSERT INTO locales (id, language, country) VALUES ('et_EE', 'Estonian', 'Estonia');
INSERT INTO locales (id, language, country) VALUES ('fi_FI', 'Finnish', 'Finland');
INSERT INTO locales (id, language, country) VALUES ('fr_BE', 'French', 'Belgium');
INSERT INTO locales (id, language, country) VALUES ('fr_CA', 'French', 'Canada');
INSERT INTO locales (id, language, country) VALUES ('fr_FR', 'French', 'France');
INSERT INTO locales (id, language, country) VALUES ('fr_LU', 'French', 'Luxembourg');
INSERT INTO locales (id, language, country) VALUES ('fr_CH', 'French', 'Switzerland');
INSERT INTO locales (id, language, country) VALUES ('de_AT', 'German', 'Austria');
INSERT INTO locales (id, language, country) VALUES ('de_DE', 'German', 'Germany');
INSERT INTO locales (id, language, country) VALUES ('de_LU', 'German', 'Luxembourg');
INSERT INTO locales (id, language, country) VALUES ('de_CH', 'German', 'Switzerland');
INSERT INTO locales (id, language, country) VALUES ('el_CY', 'Greek', 'Cyprus');
INSERT INTO locales (id, language, country) VALUES ('el_GR', 'Greek', 'Greece');
INSERT INTO locales (id, language, country) VALUES ('iw_IL', 'Hebrew', 'Israel');
INSERT INTO locales (id, language, country) VALUES ('hi_IN', 'Hindi', 'India');
INSERT INTO locales (id, language, country) VALUES ('hu_HU', 'Hungarian', 'Hungary');
INSERT INTO locales (id, language, country) VALUES ('is_IS', 'Icelandic', 'Iceland');
INSERT INTO locales (id, language, country) VALUES ('in_ID', 'Indonesian', 'Indonesia');
INSERT INTO locales (id, language, country) VALUES ('ga_IE', 'Irish', 'Ireland');
INSERT INTO locales (id, language, country) VALUES ('it_IT', 'Italian', 'Italy');
INSERT INTO locales (id, language, country) VALUES ('it_CH', 'Italian', 'Switzerland');
INSERT INTO locales (id, language, country) VALUES ('ja_JP', 'Japanese (Gregorian calendar)', 'Japan');
INSERT INTO locales (id, language, country) VALUES ('ja_JP_JP', 'Japanese (Imperial calendar)', 'Japan');
INSERT INTO locales (id, language, country) VALUES ('ko_KR', 'Korean', 'South Korea');
INSERT INTO locales (id, language, country) VALUES ('lv_LV', 'Latvian', 'Latvia');
INSERT INTO locales (id, language, country) VALUES ('lt_LT', 'Lithuanian', 'Lithuania');
INSERT INTO locales (id, language, country) VALUES ('mk_MK', 'Macedonian', 'Macedonia');
INSERT INTO locales (id, language, country) VALUES ('ms_MY', 'Malay', 'Malaysia');
INSERT INTO locales (id, language, country) VALUES ('mt_MT', 'Maltese', 'Malta');
INSERT INTO locales (id, language, country) VALUES ('no_NO', 'Norwegian (Bokmål)', 'Norway');
INSERT INTO locales (id, language, country) VALUES ('no_NO_NY', 'Norwegian (Nynorsk)', 'Norway');
INSERT INTO locales (id, language, country) VALUES ('pl_PL', 'Polish', 'Poland');
INSERT INTO locales (id, language, country) VALUES ('pt_BR', 'Portuguese', 'Brazil');
INSERT INTO locales (id, language, country) VALUES ('pt_PT', 'Portuguese', 'Portugal');
INSERT INTO locales (id, language, country) VALUES ('ro_RO', 'Romanian', 'Romania');
INSERT INTO locales (id, language, country) VALUES ('ru_RU', 'Russian', 'Russia');
INSERT INTO locales (id, language, country) VALUES ('sr_BA', 'Serbian (Cyrillic)', 'Bosnia and Herzegovina');
INSERT INTO locales (id, language, country) VALUES ('sr_ME', 'Serbian (Cyrillic)', 'Montenegro');
INSERT INTO locales (id, language, country) VALUES ('sr_RS', 'Serbian (Cyrillic)', 'Serbia');
INSERT INTO locales (id, language, country) VALUES ('sr_Latn_BA', 'Serbian (Latin)', 'Bosnia and Herzegovina');
INSERT INTO locales (id, language, country) VALUES ('sr_Latn_ME', 'Serbian (Latin)', 'Montenegro');
INSERT INTO locales (id, language, country) VALUES ('sr_Latn_RS', 'Serbian (Latin)', 'Serbia');
INSERT INTO locales (id, language, country) VALUES ('sk_SK', 'Slovak', 'Slovakia');
INSERT INTO locales (id, language, country) VALUES ('sl_SI', 'Slovenian', 'Slovenia');
INSERT INTO locales (id, language, country) VALUES ('es_AR', 'Spanish', 'Argentina');
INSERT INTO locales (id, language, country) VALUES ('es_BO', 'Spanish', 'Bolivia');
INSERT INTO locales (id, language, country) VALUES ('es_CL', 'Spanish', 'Chile');
INSERT INTO locales (id, language, country) VALUES ('es_CO', 'Spanish', 'Colombia');
INSERT INTO locales (id, language, country) VALUES ('es_CR', 'Spanish', 'Costa Rica');
INSERT INTO locales (id, language, country) VALUES ('es_DO', 'Spanish', 'Dominican Republic');
INSERT INTO locales (id, language, country) VALUES ('es_EC', 'Spanish', 'Ecuador');
INSERT INTO locales (id, language, country) VALUES ('es_SV', 'Spanish', 'El Salvador');
INSERT INTO locales (id, language, country) VALUES ('es_GT', 'Spanish', 'Guatemala');
INSERT INTO locales (id, language, country) VALUES ('es_HN', 'Spanish', 'Honduras');
INSERT INTO locales (id, language, country) VALUES ('es_MX', 'Spanish', 'Mexico');
INSERT INTO locales (id, language, country) VALUES ('es_NI', 'Spanish', 'Nicaragua');
INSERT INTO locales (id, language, country) VALUES ('es_PA', 'Spanish', 'Panama');
INSERT INTO locales (id, language, country) VALUES ('es_PY', 'Spanish', 'Paraguay');
INSERT INTO locales (id, language, country) VALUES ('es_PE', 'Spanish', 'Peru');
INSERT INTO locales (id, language, country) VALUES ('es_PR', 'Spanish', 'Puerto Rico');
INSERT INTO locales (id, language, country) VALUES ('es_ES', 'Spanish', 'Spain');
INSERT INTO locales (id, language, country) VALUES ('es_US', 'Spanish', 'United States');
INSERT INTO locales (id, language, country) VALUES ('es_UY', 'Spanish', 'Uruguay');
INSERT INTO locales (id, language, country) VALUES ('es_VE', 'Spanish', 'Venezuela');
INSERT INTO locales (id, language, country) VALUES ('sv_SE', 'Swedish', 'Sweden');
INSERT INTO locales (id, language, country) VALUES ('th_TH', 'Thai (Western digits)', 'Thailand');
INSERT INTO locales (id, language, country) VALUES ('th_TH_TH', 'Thai (Thai digits)', 'Thailand');
INSERT INTO locales (id, language, country) VALUES ('tr_TR', 'Turkish', 'Turkey');
INSERT INTO locales (id, language, country) VALUES ('uk_UA', 'Ukrainian', 'Ukraine');
INSERT INTO locales (id, language, country) VALUES ('vi_VN', 'Vietnamese', 'Vietnam');
